AudioEQ project
---------------
This project contains a functional Android equalizer app.
IMPORTANT: Please add a valid audio file at app/src/main/res/raw/sample.mp3
before building, otherwise MediaPlayer may fail at runtime (you can still build without it).
